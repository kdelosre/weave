package com.example.izaya.weavetest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Signup extends AppCompatActivity {

    DatabaseHelper helper = new DatabaseHelper(this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
    }

    public void onCreateAccountClick(View v){
        if (v.getId() == R.id.Bcreateaccount){
            EditText email = (EditText)findViewById(R.id.TFemailaddress);
            EditText username = (EditText)findViewById(R.id.TFusername);
            EditText pass = (EditText)findViewById(R.id.TFpassword);
            EditText passconfirmation = (EditText)findViewById(R.id.TFpasswordconfirm);

            String emailstr = email.getText().toString();
            String usernamestr = username.getText().toString();
            String passstr = pass.getText().toString();
            String passconfirmationstr = passconfirmation.getText().toString();

            if (!passstr.equals(passconfirmationstr)){
                //popup message
                Toast passnotmatched = Toast.makeText(Signup.this, "Passwords don't match", Toast.LENGTH_SHORT);
                passnotmatched.show();
            }

            else{
                //insert details in database to create an account
                User c = new User(usernamestr, Login.USER_ID_COUNT, emailstr, passstr);
                c.setId(Login.USER_ID_COUNT++);
                Login.addUserAttributes(c);
                helper.insertContact(c);
                Login.listOfUsers.add(c);

                // clicking create account returns to login page
                Intent i = new Intent(this, Login.class);
                startActivity(i);
            }
        }
    }

}
