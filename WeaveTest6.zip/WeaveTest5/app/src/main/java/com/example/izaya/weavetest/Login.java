package com.example.izaya.weavetest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;


public class Login extends AppCompatActivity {
    DatabaseHelper helper = new DatabaseHelper(this);
    //profile userProfile = new profile();
    public static String username;
    TextView displayUsernames;
    public static int USER_ID_COUNT = 0; //tracks each user with an ID and counts # of users
    public static ArrayList<User> listOfUsers = new ArrayList<User>(USER_ID_COUNT);
    public static ArrayList<String> userAttributes; //empty list containing user attributes


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        createFakeUser();

        //attempt to display on UI part, but it breaks.
        /*displayUsernames = (TextView) findViewById(R.id.contactNames);
        for (String name: getAllUsernames()) {
            displayUsernames.append(name);
        }*/
}


    //returns ['User', 'id', 'email, 'pass']
    public static ArrayList<String> addUserAttributes(User singleUser) {
        userAttributes = new ArrayList<String>(4);
        userAttributes.add(singleUser.getUsername());
        userAttributes.add(Integer.toString(singleUser.getId()));
        userAttributes.add(singleUser.getEmailAddress());
        userAttributes.add(singleUser.getPassword());
        return userAttributes;
    }

    // Create fake contact and add to database, then add each contact to list of all users
    public void createFakeUser() {
        User c1 = new User("Ray", USER_ID_COUNT, "Ray","Ray");
        c1.setId(USER_ID_COUNT++);
        addUserAttributes(c1);
        helper.insertContact(c1);

        User c2 = new User("Sally", USER_ID_COUNT, "Sally", "Sally");
        c2.setId(USER_ID_COUNT++);
        addUserAttributes(c2);
        helper.insertContact(c2);

        User c3 = new User("Jonathan", USER_ID_COUNT, "Jonathan", "Jonathan");
        c3.setId(USER_ID_COUNT++);
        addUserAttributes(c3);
        helper.insertContact(c3);

        User c4 = new User("Lily", USER_ID_COUNT, "Lily", "Lily");
        c4.setId(USER_ID_COUNT++);
        addUserAttributes(c4);
        helper.insertContact(c4);

        listOfUsers.add(c1);
        listOfUsers.add(c2);
        listOfUsers.add(c3);
        listOfUsers.add(c4);
    }

    // Adds each user's "username" to a list and returns the String list to be displayed on Second_layout
    public ArrayList<String> getAllUsernames() {
        ArrayList<String> listUsernames;
        listUsernames = new ArrayList<String>();
        for (User oneUser: listOfUsers) {
            for (String attribute: userAttributes) {
                listUsernames.add(userAttributes.get(0));
            }
        }
        return listUsernames;
    }

    public void onButtonClick(View v) {
        if (v.getId() == R.id.Blogin) {

            EditText a = (EditText) findViewById(R.id.TFusername);
            String uname = a.getText().toString();
            EditText b = (EditText) findViewById(R.id.TFpassword);
            String pass = b.getText().toString();

            String password = helper.searchPass(uname);
            if (pass.equals(password)) {
                username =  uname;
                //userProfile.placeUsername(uname);
                Intent i = new Intent(this, MainActivity.class);
                startActivity(i);
            }

            else {
                Toast temp = Toast.makeText(Login.this, "Username or password is incorrect", Toast.LENGTH_SHORT);
                temp.show();
            }
        }

        if (v.getId() == R.id.TxtSignup) {
//            Log.i("Custom Check", "TESTING ERROR");
            Intent i = new Intent(this, Signup.class);
            startActivity(i);
        }
    }
}
