package com.example.izaya.weavetest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.MutableInt;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by joharahalomair on 4/30/16.
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "contacts.db";
    private static final String TABLE_NAME = "contacts";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_EMAIL = "email";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "pass";
    private static final String COLUMN_THREAD1ID = "thread1id";
    private static final String COLUMN_THREAD1NAME = "thread1";
    private static final String COLUMN_THREAD1IMAGE = "thread1image";
    private static final String COLUMN_THREAD1COMMENT = "thread1comment";
    private static final String COLUMN_THREAD1DATE = "thread1date";
    private static final String COLUMN_THREAD1LOCATION = "thread1location";




    SQLiteDatabase sqLiteDatabase;
    private static final String TABLE_CREATE = "create table contacts (id integer primary key not null , " + "email text not null , username text not null , pass text not null);";

    public DatabaseHelper(Context context){

        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(TABLE_CREATE);
        this.sqLiteDatabase = sqLiteDatabase;
    }

    public void insertContact(User c){
        sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String query = "select * from contacts";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();

        values.put(COLUMN_ID, count);
        values.put(COLUMN_EMAIL, c.getEmailAddress());
        values.put(COLUMN_USERNAME, c.getUsername());
        values.put(COLUMN_PASSWORD, c.getPassword());

        sqLiteDatabase.insert(TABLE_NAME, null, values);
        sqLiteDatabase.close();
    }

    public void insertThread(HashMap thread){
        sqLiteDatabase = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        String query = "select * from contacts";
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        int count = cursor.getCount();
        values.put(COLUMN_THREAD1NAME, (String) thread.get("Title"));
        values.put(COLUMN_THREAD1IMAGE, (Byte) thread.get("ThreadImage"));
        values.put(COLUMN_THREAD1COMMENT, (String) thread.get("Comments"));
        values.put(COLUMN_THREAD1DATE, (String) thread.get("Date"));
        values.put(COLUMN_THREAD1LOCATION, (String) thread.get("Location"));
        values.put(COLUMN_THREAD1ID, (Integer) thread.get("ThreadID"));
        //columnthreqad.put()
        //values.put(COLUMN_THREADS, thread.getThread());
        //COLUMN_THREAD.add(thread.getThread());
        //values.put(COLUMN_THREADS);



        sqLiteDatabase.insert(TABLE_NAME, null, values);
        sqLiteDatabase.close();

    }

    public String searchPass(String uname){
        sqLiteDatabase = this.getReadableDatabase();
        String query = "select username, pass from "+TABLE_NAME;
        Cursor cursor = sqLiteDatabase.rawQuery(query, null);
        String a,b;
        b = "not found";
        if (cursor.moveToFirst()){
            do{
                a = cursor.getString(0);
                b = cursor.getString(1);

                if (a.equals(uname)){
                    b = cursor.getString(1);
                    break;
                }
            }while(cursor.moveToNext());
        }
        return b;
    }
/*
    public Thread getThreadData(int id){
        sqLiteDatabase = this.getReadableDatabase();
        Cursor cursor = sqLiteDatabase.query();
    }*/

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        String query = "DROP TABLE IF EXISTS" + TABLE_NAME;
        sqLiteDatabase.execSQL(query);
        this.onCreate(sqLiteDatabase);
    }
}
