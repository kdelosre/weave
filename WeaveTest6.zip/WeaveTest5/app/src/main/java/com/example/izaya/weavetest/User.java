package com.example.izaya.weavetest;

import java.util.ArrayList;

/**
 * Created by joharahalomair on 4/30/16.
 */

// Old class named "Contact", user class contains all fields related to a user
public class User {
    int id;
    String email, username, pass;

    public User(String userName, int idNum, String emailAddress, String password){
        this.id = idNum;
        this.email = emailAddress;
        this.username = userName;
        this.pass = password;
    }

   public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }

    public void setEmailAddress(String email){
        this.email = email;
    }
    public String getEmailAddress(){
        return this.email;
    }

    public void setUsername(String username){
        this.username = username;
    }
    public String getUsername(){
        return this.username;
    }

    public void setPassword(String pass){
        this.pass = pass;
    }
    public String getPassword(){
        return this.pass;
    }

    @Override
    public String toString() {
        return username;
    }
}
