package com.example.izaya.weavetest;

/**
 * Created by joharahalomair on 4/30/16.
 */
public class Contact {
    int id;
    String email, username, pass;


    public void setId(int id){
        this.id = id;
    }
    public int getId(){
        return this.id;
    }

    public void setEmailAddress(String email){
        this.email = email;
    }
    public String getEmailAddress(){
        return this.email;
    }

    public void setUsername(String username){
        this.username = username;
    }
    public String getUsername(){
        return this.username;
    }

    public void setPassword(String pass){
        this.pass = pass;
    }
    public String getPassword(){
        return this.pass;
    }
}
