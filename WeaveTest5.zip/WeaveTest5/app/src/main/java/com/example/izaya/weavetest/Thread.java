package com.example.izaya.weavetest;

import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.sql.Array;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

/**
 * Created by joharahalomair on 5/18/16.
 */
public class Thread extends AppCompatActivity {
    ImageView imgPicture;
    Uri imageUri;
    String currentPhotoPath;
    File photoFile;
    private static final int IMAGE_GALLERY_REQUEST = 2;
    private static final int TAKE_PICTURE = 3;
    private ArrayList threadInformation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_createthread);
        imgPicture = (ImageView) findViewById(R.id.threadImage);
        threadInformation = new ArrayList();


    }

    public void onThreadClick(View v) {
        if (v.getId() == R.id.dashboard) {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        } else if (v.getId() == R.id.photoGallery) {
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, IMAGE_GALLERY_REQUEST);
        } else if (v.getId() == R.id.cameraIcon) {
            takePhoto(v);
        } else if (v.getId() == R.id.shareThread){
            storeThreadInfo();
            //Signup.helper.insertThread();
        }
    }
    private ArrayList<Array> storeThreadInfo(){
        EditText Title = (EditText)findViewById(R.id.threadTitle);
        EditText Comment= (EditText)findViewById(R.id.threadComment);
        EditText Date = (EditText)findViewById(R.id.threadDate);
        EditText Location = (EditText)findViewById(R.id.threadLocation);
        //also add tagged users

        String threadTitle = Title.getText().toString();
        String threadComment = Comment.getText().toString();
        String threadDate = Date.getText().toString();
        String threadLocation = Location.getText().toString();

        //threadInformation.add();

        return threadInformation;
    }

    private void takePhoto(View v) {
        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        /*File photo = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "picture.jpg");
        imageUri = Uri.fromFile(photo);
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(cameraIntent, TAKE_PICTURE);*/
        if (cameraIntent.resolveActivity(getPackageManager()) != null){
            photoFile = null;
            try{
                photoFile = createImageFile();
            }catch(IOException e){
                Log.i("custom message", e.toString());
            }
            if (photoFile != null) {
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
                startActivityForResult(cameraIntent, TAKE_PICTURE);
            }
        }
    }

    private File createImageFile() throws IOException {
        //create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(imageFileName, ",jpg", storageDir);

        //save a file: path for use with ACTION_VIEW intents
        currentPhotoPath = "file:" + image.getAbsolutePath();
        return image;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == IMAGE_GALLERY_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            imgPicture.setImageURI(selectedImage);
        }
        else if (requestCode == TAKE_PICTURE && resultCode == RESULT_OK && data != null){
            //Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) data.getExtras().get("data");
            imgPicture.setImageBitmap(imageBitmap);
            /*Uri selectedImage = imageUri;
            getContentResolver().notifyChange(selectedImage, null);
            ContentResolver cr = getContentResolver();
            Bitmap bitmap;

            try{
                bitmap = MediaStore.Images.Media.getBitmap(cr, selectedImage);
                imgPicture.setImageBitmap(bitmap);
                Toast.makeText(Thread.this, selectedImage.toString(), Toast.LENGTH_SHORT).show();

            }catch (Exception e){
                Log.i("custom message" , e.toString());
            }*/
        }
    }

}
