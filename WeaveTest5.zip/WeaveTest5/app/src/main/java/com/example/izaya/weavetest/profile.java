package com.example.izaya.weavetest;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class profile extends AppCompatActivity{ //implements View.OnClickListener{

    private static final int GALLERY_FOR_PROFILE_REQUEST = 1;
    private static final int IMAGE_GALLERY_REQUEST = 2;
    DatabaseHelper helper = new DatabaseHelper(this);
    ImageView profilePicture;
    TextView username;
    String uname;
    //ImageView imgPicture;
    Thread newThread;
    ImageView drawerProfile;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profilePicture = (ImageView) findViewById(R.id.profilephotoonProfile);
        drawerProfile = (ImageView) findViewById(R.id.drawerProfilepic);
        //Thread.imgPicture = (ImageView) findViewById(R.id.threadImage);
        this.username = (TextView) findViewById(R.id.username);
        this.username.setText("");
        this.username.append(Login.username);
        Thread newThread = new Thread();
        newThread.imgPicture = (ImageView)findViewById(R.id.threadImage);
        }

        //profilePicture.setOnClickListener(this);



    public void onDashboardClick(View v){
        if (v.getId() == R.id.cameraIcon) {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }
        else if (v.getId() == R.id.dashboard) {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
        }
        //else if (v.getId() == R.id.photoGallery){
          //  Log.i("check", "in else if");

        //}

        //else if (v.getId() == R.id.profilephotoonProfile){
        //    Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        //    startActivityForResult(galleryIntent, IMAGE_GALLERY_REQUEST);
       // }
        //should add another else if statement for notifications.
    }
    public void onClick(View v){
        if (v.getId() == R.id.profilephotoonProfile){
            Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
            startActivityForResult(galleryIntent, GALLERY_FOR_PROFILE_REQUEST);
        }

    }
    public void onGalleryClick(View v){
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, IMAGE_GALLERY_REQUEST);
        Intent i = new Intent(this, Thread.class);
        startActivity(i);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == GALLERY_FOR_PROFILE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri selectedImage = data.getData();
            profilePicture.setImageURI(selectedImage);
            //drawerProfile.setImageURI(selectedImage);


        }
    }


    public void placeUsername(String name){
        this.uname = name;
    }

}
