package com.example.izaya.weavetest;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


public class Login extends AppCompatActivity {
    DatabaseHelper helper = new DatabaseHelper(this);
    //profile userProfile = new profile();
    public static String username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void onButtonClick(View v) {
        if (v.getId() == R.id.Blogin) {

            EditText a = (EditText) findViewById(R.id.TFusername);
            String uname = a.getText().toString();
            EditText b = (EditText) findViewById(R.id.TFpassword);
            String pass = b.getText().toString();

            String password = helper.searchPass(uname);
            if (pass.equals(password)) {
                username =  uname;
                //userProfile.placeUsername(uname);
                Intent i = new Intent(this, MainActivity.class);
                startActivity(i);
            }

            else {
                Toast temp = Toast.makeText(Login.this, "Username or password is incorrect", Toast.LENGTH_SHORT);
                temp.show();
            }

        }

        if (v.getId() == R.id.TxtSignup) {
//            Log.i("Custom Check", "TESTING ERROR");
            Intent i = new Intent(this, Signup.class);
            startActivity(i);
        }
    }
}
